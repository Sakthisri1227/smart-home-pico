# ============================================================
# energy_monitor.py
# Energy Monitoring Module for Smart Home System
# Raspberry Pi Pico | MicroPython
# ============================================================

import utime

class EnergyMonitor:
    """Tracks power and energy consumption over time."""

    def __init__(self, voltage=230.0, rate_per_kwh=6.5):
        self.voltage        = voltage         # Mains voltage (V)
        self.rate_per_kwh   = rate_per_kwh   # ₹ per kWh
        self.total_energy_wh = 0.0
        self.session_start  = utime.time()
        self.history        = []              # List of (timestamp, power_W)

    def update(self, current_A, dt_seconds):
        """Call every loop iteration with current reading and time delta."""
        power_W = self.voltage * current_A
        energy_wh = power_W * (dt_seconds / 3600)
        self.total_energy_wh += energy_wh

        timestamp = utime.time() - self.session_start
        self.history.append((timestamp, round(power_W, 2)))

        # Keep only last 100 readings to save memory
        if len(self.history) > 100:
            self.history.pop(0)

        return power_W, energy_wh

    @property
    def total_kwh(self):
        return self.total_energy_wh / 1000

    @property
    def estimated_cost(self):
        return self.total_kwh * self.rate_per_kwh

    @property
    def session_duration_min(self):
        return (utime.time() - self.session_start) / 60

    def get_summary(self):
        """Returns a formatted summary string."""
        return (
            f"Session Duration : {self.session_duration_min:.1f} min\n"
            f"Total Energy     : {self.total_energy_wh:.3f} Wh\n"
            f"Total kWh        : {self.total_kwh:.6f} kWh\n"
            f"Estimated Cost   : Rs {self.estimated_cost:.4f}"
        )

    def reset(self):
        """Reset energy counter (e.g., at midnight for daily tracking)."""
        self.total_energy_wh = 0.0
        self.history.clear()
        self.session_start = utime.time()
        print("[EnergyMonitor] Daily counter reset.")
