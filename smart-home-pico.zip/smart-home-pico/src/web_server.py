# ============================================================
# web_server.py
# Simple Web Server for Pico W (Wi-Fi enabled)
# Serves live energy data as JSON at /data
# ============================================================
# NOTE: This file only works on Raspberry Pi Pico W (has Wi-Fi)
# For regular Pico, use Serial Monitor only.
# ============================================================

import network
import socket
import ujson
import utime
from machine import ADC, Pin

# ── Wi-Fi Credentials ────────────────────────────────────────
SSID     = "Your_WiFi_Name"       # ← Change this
PASSWORD = "Your_WiFi_Password"   # ← Change this

# ── Connect to Wi-Fi ─────────────────────────────────────────
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, PASSWORD)
    print("Connecting to Wi-Fi", end="")
    timeout = 15
    while not wlan.isconnected() and timeout > 0:
        print(".", end="")
        utime.sleep(1)
        timeout -= 1
    if wlan.isconnected():
        print(f"\nConnected! IP: {wlan.ifconfig()[0]}")
        return wlan.ifconfig()[0]
    else:
        print("\nFailed to connect. Running in Serial-only mode.")
        return None

# ── Shared state (updated by main loop) ──────────────────────
state = {
    "motion": 0,
    "brightness": 0,
    "current_A": 0.0,
    "power_W": 0.0,
    "energy_wh": 0.0,
    "light": "OFF",
    "fan": "OFF",
    "cost_rs": 0.0,
    "uptime_sec": 0
}

# ── HTTP Response Builder ─────────────────────────────────────
HTML_PAGE = """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="3">
  <title>Smart Home Dashboard</title>
  <style>
    body { font-family: monospace; background: #0d1117; color: #58a6ff; padding: 20px; }
    h1   { color: #f0f6fc; }
    .card { background: #161b22; border: 1px solid #30363d; padding: 15px;
            margin: 10px 0; border-radius: 8px; }
    .on  { color: #3fb950; } .off { color: #f85149; }
    table { width: 100%; border-collapse: collapse; }
    td { padding: 6px 10px; border-bottom: 1px solid #21262d; }
  </style>
</head>
<body>
  <h1>⚡ Smart Home Energy Dashboard</h1>
  <div class="card">
    <table id="data">
      <tr><td>Motion</td><td id="motion">-</td></tr>
      <tr><td>Brightness</td><td id="brightness">-</td></tr>
      <tr><td>Current</td><td id="current">-</td></tr>
      <tr><td>Power</td><td id="power">-</td></tr>
      <tr><td>Energy</td><td id="energy">-</td></tr>
      <tr><td>Cost</td><td id="cost">-</td></tr>
      <tr><td>Light</td><td id="light">-</td></tr>
      <tr><td>Fan</td><td id="fan">-</td></tr>
    </table>
  </div>
  <script>
    async function refresh() {
      const r = await fetch('/data');
      const d = await r.json();
      document.getElementById('motion').textContent = d.motion ? 'YES' : 'NO';
      document.getElementById('brightness').textContent = d.brightness + '%';
      document.getElementById('current').textContent = d.current_A.toFixed(3) + ' A';
      document.getElementById('power').textContent = d.power_W.toFixed(2) + ' W';
      document.getElementById('energy').textContent = d.energy_wh.toFixed(4) + ' Wh';
      document.getElementById('cost').textContent = '₹ ' + d.cost_rs.toFixed(4);
      document.getElementById('light').textContent = d.light;
      document.getElementById('fan').textContent = d.fan;
    }
    setInterval(refresh, 3000);
    refresh();
  </script>
</body>
</html>"""

def handle_request(conn, request):
    if b"GET /data" in request:
        body = ujson.dumps(state)
        response = (
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/json\r\n"
            "Access-Control-Allow-Origin: *\r\n\r\n"
        ) + body
    else:
        response = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n" + HTML_PAGE
    conn.send(response.encode())
    conn.close()

def start_server(ip):
    addr = socket.getaddrinfo("0.0.0.0", 80)[0][-1]
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(addr)
    s.listen(1)
    s.setblocking(False)
    print(f"Web server running at http://{ip}/")
    return s
