# 🔌 Circuit Diagram & Wiring Guide

## Raspberry Pi Pico Pin Reference

```
                    ┌───────────────────┐
               GP0 ─┤ 1             40 ├─ VBUS (5V)
               GP1 ─┤ 2             39 ├─ VSYS
               GND ─┤ 3             38 ├─ GND
               GP2 ─┤ 4             37 ├─ 3V3_EN
               GP3 ─┤ 5             36 ├─ 3V3 OUT
               GP4 ─┤ 6             35 ├─ ADC_VREF
               GP5 ─┤ 7             34 ├─ GP28 (ADC2)
               GND ─┤ 8             33 ├─ GND
               GP6 ─┤ 9             32 ├─ GP27 (ADC1) ← LDR
               GP7 ─┤10             31 ├─ GP26 (ADC0) ← ACS712
               GP8 ─┤11             30 ├─ RUN
               GP9 ─┤12             29 ├─ GP22
               GND ─┤13             28 ├─ GND
              GP10 ─┤14             27 ├─ GP21
              GP11 ─┤15             26 ├─ GP20
              GP12 ─┤16             25 ├─ GP19
   Relay2(Fan) GP13 ┤17             24 ├─ GP18
  Relay1(Lgt) GP14 ─┤18             23 ├─ GND
  PIR Sensor  GP15 ─┤19             22 ├─ GP17
               GND ─┤20             21 ├─ GP16
                    └───────────────────┘
```

---

## Component Wiring Details

### 1. ACS712 Current Sensor (5A Module)
| ACS712 Pin | Connects To |
|---|---|
| VCC | Pico 3.3V |
| GND | Pico GND |
| OUT | Pico GP26 (ADC0) |
| IP+ | AC Live wire IN |
| IP- | AC Live wire OUT (to load) |

> ⚠️ **Safety**: The IP+/IP- pins carry mains voltage. Handle with care!

---

### 2. PIR Motion Sensor (HC-SR501)
| PIR Pin | Connects To |
|---|---|
| VCC | Pico VBUS (5V) or 3.3V |
| GND | Pico GND |
| OUT | Pico GP15 |

> Adjust sensitivity and delay potentiometers on the module as needed.

---

### 3. LDR (Light Dependent Resistor)
```
3.3V ──── LDR ──┬── 10kΩ Resistor ──── GND
                │
               GP27 (ADC1)
```
> Voltage divider circuit — GP27 reads analog voltage proportional to light level.

---

### 4. Relay Module (5V, 1-channel or 2-channel)
| Relay Pin | Connects To |
|---|---|
| VCC | Pico 5V (VBUS) |
| GND | Pico GND |
| IN1 (Light) | Pico GP14 |
| IN2 (Fan) | Pico GP13 |
| COM | AC Neutral |
| NO | Appliance terminal |

> **NO** = Normally Open. Appliance is OFF by default, ON when relay triggers.

---

## Full System Wiring Diagram (Text)

```
   AC MAINS (230V)
        │
        ├─ NEUTRAL ──────────────────────────── Appliance Neutral
        │
        └─ LIVE ──── ACS712 IP+ ──── ACS712 IP- ──── Relay COM
                                                           │
                                                       Relay NO
                                                           │
                                                      Appliance Live

   Raspberry Pi Pico
   ┌─────────────────┐
   │ GP26 ←─ ACS712 OUT           (Current Sensing)
   │ GP27 ←─ LDR Divider          (Light Level)
   │ GP15 ←─ PIR OUT              (Motion Detection)
   │ GP14 ──→ Relay1 IN1          (Light Control)
   │ GP13 ──→ Relay2 IN2          (Fan Control)
   │ 3V3  ──→ ACS712 VCC
   │ VBUS ──→ PIR VCC, Relay VCC
   │ GND  ──→ All GNDs
   └─────────────────┘
```

---

## Safety Notes

1. **Never touch mains wiring while powered on**
2. Use properly insulated wires for AC side
3. Keep Pico (low voltage) and AC (high voltage) sections physically separated
4. Use a fuse on the AC input (1A recommended for demo loads)
5. For demo/college project: use a 12V DC bulb instead of 230V AC for safety
