# 📖 Working Principle – Detailed Explanation

## System Overview

The Smart Energy-Efficient Home Automation System uses a Raspberry Pi Pico as the central controller. It reads data from three sensors, makes intelligent decisions, controls appliances via relays, and continuously monitors energy consumption.

---

## Step-by-Step Working

### Step 1: Sensor Data Acquisition

Every 2 seconds, the Pico reads:

| Sensor | Data Read | How |
|---|---|---|
| ACS712 | AC current (Amps) | Analog → ADC (GP26) |
| PIR | Motion (Yes/No) | Digital High/Low (GP15) |
| LDR | Brightness (%) | Analog → ADC (GP27) |

---

### Step 2: Decision Logic (Smart Control)

```
IF motion detected AND room is dark:
    → Light ON, Fan ON

IF no motion for 30 seconds:
    → Light AUTO-OFF, Fan AUTO-OFF   ← Energy Saving!

IF room is bright (LDR > threshold):
    → Light OFF (natural light is sufficient)
```

This prevents appliances from running when nobody is home.

---

### Step 3: Energy Calculation

```
Power (W)  = Voltage (V) × Current (A)
           = 230 × I

Energy (Wh) = Power × Time
            = P × (seconds / 3600)

Daily kWh   = Total Wh / 1000

Cost (₹)    = kWh × Electricity Rate
```

This runs every loop cycle, accumulating over the session.

---

### Step 4: Output & Display

- **Serial Monitor** (Thonny/Arduino IDE): Real-time data every 2s
- **Web Dashboard** (Pico W only): Browser-based live monitoring at local IP

---

## Energy Saving Scenarios

| Scenario | System Action | Energy Saved |
|---|---|---|
| User leaves room | Auto-OFF after 30s | High |
| Sunny daytime | Lights OFF via LDR | Medium |
| Night + motion | Only needed lights ON | Medium |
| No activity at all | All appliances OFF | Maximum |

---

## Comparison: Manual vs Smart System

```
Manual System:
  User forgets lights ON → Wastes energy all day 💸

Smart System:
  No motion for 30 seconds → Auto OFF → Energy saved ✅
```

---

## ACS712 – How It Measures Current

The ACS712 is a Hall Effect current sensor. It outputs a voltage proportional to the current flowing through it:

- **Zero current**: Output = 2.5V (midpoint of 5V supply, ~1.65V at 3.3V)
- **Positive current**: Voltage rises above midpoint
- **Formula**: `I = (Vout - Vmid) / Sensitivity`
- Sensitivity for 5A module = **185 mV/A**

The Pico's ADC reads this voltage (0–3.3V range) and converts it to current.

---

## Why Raspberry Pi Pico?

| Feature | Arduino Uno | Raspberry Pi Pico |
|---|---|---|
| CPU | 8-bit AVR | 32-bit ARM Cortex-M0+ |
| Clock | 16 MHz | 133 MHz |
| ADC | 10-bit | 12-bit |
| Price | ~₹400 | ~₹350 |
| Python | ❌ | ✅ MicroPython |
| Dual Core | ❌ | ✅ |

The Pico is more powerful, cheaper, and supports MicroPython — ideal for this project.
