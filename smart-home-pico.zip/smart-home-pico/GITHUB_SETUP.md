# 🚀 How to Upload This Project to GitHub

## Step 1: Create GitHub Account
If you don't have one → https://github.com/signup

---

## Step 2: Create a New Repository

1. Go to https://github.com/new
2. Repository name: `smart-home-pico` (or your choice)
3. Description: `Smart Energy-Efficient Home Automation System using Raspberry Pi Pico`
4. Set to **Public**
5. ✅ Check "Add a README file" → NO (we already have one)
6. Click **Create repository**

---

## Step 3: Upload Files (Easy Method — GitHub Web)

1. Open your new repo on GitHub
2. Click **"uploading an existing file"** or **"Add file → Upload files"**
3. Drag and drop the entire `smart-home-pico/` folder contents
4. Write commit message: `Initial commit - Smart Home Automation Project`
5. Click **Commit changes**

---

## Step 4: Upload via Git (Terminal Method)

```bash
# Install Git if not installed
# Windows: https://git-scm.com/download/win

# Navigate to project folder
cd smart-home-pico

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Smart Energy Home Automation System"

# Add your GitHub repo URL (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/smart-home-pico.git

# Push to GitHub
git branch -M main
git push -u origin main
```

---

## Step 5: Make It Look Professional

After uploading:
1. Go to repo **Settings** → **General** → Add topics:
   - `raspberry-pi-pico`
   - `micropython`
   - `home-automation`
   - `energy-monitoring`
   - `iot`
2. Add your project photo: Edit `README.md` → replace the photo placeholder
3. Pin the repo to your GitHub profile

---

## Suggested Folder Upload Order

```
smart-home-pico/
├── README.md          ← Upload first (most important)
├── src/
│   ├── main.py
│   ├── energy_monitor.py
│   └── web_server.py
├── dashboard/
│   └── index.html
└── docs/
    ├── circuit_diagram.md
    └── working_principle.md
```
